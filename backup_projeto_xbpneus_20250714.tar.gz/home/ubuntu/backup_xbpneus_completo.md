# BACKUP COMPLETO - PROJETO XBPNEUS
**Data:** 14/07/2025  
**Versão:** Sistema de Gestão de Frota com Estoque de Pneus  
**Status:** Funcional com novo sistema de estoque implementado

## 📋 ESTRUTURA DO PROJETO

### **Tecnologias Utilizadas:**
- **Backend:** Django 4.2+ (Python)
- **Frontend:** HTML5, CSS3, Bootstrap 5, JavaScript
- **Banco:** PostgreSQL (Railway)
- **Deploy:** Railway.app
- **Repositório:** GitHub

### **Apps Django:**
1. **core** - Funcionalidades centrais
2. **home** - Página inicial
3. **produtos** - Catálogo de produtos
4. **servicos** - Serviços oferecidos
5. **contato** - Formulário de contato
6. **frota** - Gestão de veículos e pneus
7. **subusuarios** - Gestão de usuários secundários
8. **transportadores** - Cadastro de empresas transportadoras

## 🚛 SISTEMA DE FROTA (Principal)

### **Funcionalidades Atuais:**
- ✅ **Cadastro de Veículos** (placa, modelo, cor, ano, KM)
- ✅ **Sistema de Estoque de Pneus** (NOVO - implementado)
- ✅ **Vinculação Pneu → Veículo** (controle de posição)
- ✅ **Histórico de Movimentação** (entrada, montagem, remoção)
- ✅ **Relatórios e Dashboard** (estatísticas completas)
- ✅ **Controle de Status** (disponível, em uso, reformado, descartado)

### **Models Principais:**

#### **1. Veiculo**
```python
- usuario (ForeignKey User)
- placa (CharField, unique)
- modelo (CharField)
- cor (CharField)
- km (IntegerField)
- ano (IntegerField)
- data_cadastro (DateTimeField)
```

#### **2. PneuEstoque (NOVO)**
```python
- usuario (ForeignKey User)
- numero_nf (CharField)
- fornecedor (CharField)
- data_entrada (DateField)
- marca (CharField)
- modelo (CharField)
- medida (CharField, choices)
- tipo (CharField: novo/usado/reformado)
- numero_serie (CharField, unique)
- dot (CharField)
- valor_unitario (DecimalField)
- status (CharField: disponivel/em_uso/reformado/descartado)
- observacoes (TextField)
```

#### **3. VinculacaoPneu (NOVO)**
```python
- pneu_estoque (ForeignKey PneuEstoque)
- veiculo (ForeignKey Veiculo)
- posicao (CharField, choices)
- data_montagem (DateField)
- km_montagem (IntegerField)
- pressao_atual (DecimalField)
- sulco_externo/central/interno (DecimalField)
- ativo (BooleanField)
- data_remocao (DateField, nullable)
- km_remocao (IntegerField, nullable)
- motivo_remocao (TextField)
```

#### **4. HistoricoMovimentacao (NOVO)**
```python
- pneu_estoque (ForeignKey PneuEstoque)
- tipo_movimento (CharField: entrada/montagem/remocao/manutencao/reforma/descarte)
- data_movimento (DateTimeField)
- veiculo (ForeignKey Veiculo, nullable)
- km_veiculo (IntegerField, nullable)
- custo (DecimalField, nullable)
- descricao (TextField)
- usuario (ForeignKey User)
```

## 🔄 FLUXO OPERACIONAL

### **1. Entrada de Pneus:**
1. Financeiro cadastra pneus via NF
2. Status inicial: "Disponível"
3. Registro automático no histórico

### **2. Montagem em Veículo:**
1. Seleção de pneu disponível
2. Escolha de veículo e posição
3. Status muda para "Em uso"
4. Registro de data/KM de montagem

### **3. Controle e Manutenção:**
1. Atualização periódica de sulcos
2. Controle de pressão
3. Histórico de manutenções

### **4. Remoção:**
1. Registro de motivo da remoção
2. Status volta para "Disponível" ou "Descartado"
3. Histórico completo mantido

## 📊 MÉTRICAS E RELATÓRIOS ATUAIS

### **Dashboard Principal:**
- Total de veículos cadastrados
- Total de pneus no estoque
- Pneus por status (disponível/em uso/etc)
- Valor total do estoque
- Pneus que precisam atenção (sulco baixo)

### **Relatórios Disponíveis:**
- Estoque por marca/medida/status
- Histórico de movimentação
- Custo por veículo
- Previsão de trocas (baseado em sulco)

## 🎯 OPORTUNIDADES DE MELHORIA (Para ChatGPT)

### **Métricas Avançadas Sugeridas:**
1. **Análise de Desempenho:**
   - KM médio por pneu
   - Custo por KM rodado
   - Vida útil média por marca/modelo
   - ROI de pneus reformados vs novos

2. **Predições e Alertas:**
   - Previsão de troca baseada em padrões
   - Alertas de estoque mínimo
   - Sugestões de compra otimizada
   - Identificação de padrões de desgaste

3. **Análise Financeira:**
   - Custo total de propriedade (TCO)
   - Análise de fornecedores
   - Sazonalidade de preços
   - Budget vs realizado

4. **Eficiência Operacional:**
   - Tempo médio de montagem/desmontagem
   - Produtividade da frota
   - Indicadores de manutenção preventiva
   - Benchmarking entre veículos

5. **Dashboards Executivos:**
   - KPIs consolidados
   - Gráficos de tendência
   - Comparativos mensais/anuais
   - Alertas críticos

## 🔧 ARQUIVOS PRINCIPAIS DO PROJETO

### **Configuração:**
- `xbpneus/config/settings.py` - Configurações Django
- `xbpneus/config/urls.py` - URLs principais
- `requirements.txt` - Dependências
- `Dockerfile` - Configuração de deploy

### **Apps Frota:**
- `xbpneus/apps/frota/models.py` - Models originais
- `xbpneus/apps/frota/models_estoque.py` - Novos models de estoque
- `xbpneus/apps/frota/views.py` - Views originais
- `xbpneus/apps/frota/views_estoque.py` - Views do estoque
- `xbpneus/apps/frota/forms.py` - Formulários originais
- `xbpneus/apps/frota/forms_estoque.py` - Formulários do estoque
- `xbpneus/apps/frota/urls.py` - URLs principais
- `xbpneus/apps/frota/urls_estoque.py` - URLs do estoque

### **Templates:**
- `xbpneus/templates/base/base.html` - Template base
- `xbpneus/templates/painel.html` - Dashboard principal
- `xbpneus/apps/frota/templates/frota/` - Templates da frota

## 🚀 STATUS ATUAL

### **Funcionando:**
- ✅ Sistema de login/autenticação
- ✅ Cadastro de veículos
- ✅ Sistema de estoque (backend completo)
- ✅ Vinculação pneu-veículo
- ✅ Histórico de movimentações
- ✅ Relatórios básicos

### **Em Desenvolvimento:**
- 🔄 Templates do novo sistema de estoque
- 🔄 Integração completa com menu
- 🔄 Migrações do banco

### **Próximas Implementações:**
- 📋 Métricas avançadas (ChatGPT)
- 📋 Dashboards executivos
- 📋 Alertas inteligentes
- 📋 APIs para integração

## 🌐 DEPLOY E ACESSO

- **URL Temporária:** https://courteous-gentleness-fer.up.railway.app/
- **URL Futura:** app.xbpneus.com (DNS em propagação)
- **Repositório:** GitHub (xbpneus-gestao-de-frota/FER)
- **Plataforma:** Railway.app

## 👥 USUÁRIOS E PERMISSÕES

### **Usuário de Teste:**
- **Login:** cliente_teste
- **Senha:** senha123

### **Hierarquia:**
- **Usuário Principal:** Acesso completo
- **Subusuários:** Permissões específicas por função
- **Transportadores:** Perfil de empresa

---

**INSTRUÇÕES PARA CHATGPT:**
Analise este backup completo e implemente métricas avançadas, dashboards executivos e funcionalidades de BI para otimizar a gestão de frota. Foque em:
1. Análise preditiva de trocas
2. Otimização de custos
3. KPIs executivos
4. Alertas inteligentes
5. Relatórios gerenciais avançados

