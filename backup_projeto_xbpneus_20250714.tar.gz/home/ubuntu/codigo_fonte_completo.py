# ===== CÓDIGO FONTE COMPLETO - PROJETO XBPNEUS =====
# Data: 14/07/2025
# Sistema de Gestão de Frota com Estoque de Pneus

# ===== 1. MODELS PRINCIPAIS =====

# ----- xbpneus/apps/frota/models.py -----
"""
from django.db import models
from django.contrib.auth.models import User

class Veiculo(models.Model):
    usuario = models.ForeignKey(User, on_delete=models.CASCADE, related_name='veiculos')
    placa = models.CharField(max_length=8, unique=True, verbose_name='Placa')
    modelo = models.CharField(max_length=100, verbose_name='Modelo')
    cor = models.CharField(max_length=50, verbose_name='Cor')
    km = models.IntegerField(verbose_name='Quilometragem')
    ano = models.IntegerField(verbose_name='Ano')
    data_cadastro = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name = 'Veículo'
        verbose_name_plural = 'Veículos'
        ordering = ['-data_cadastro']
    
    def __str__(self):
        return f"{self.placa} - {self.modelo}"

class Pneu(models.Model):
    MEDIDAS_CHOICES = [
        ('225/75/16', '225/75/16'),
        ('215/75/17.5', '215/75/17.5'),
        ('235/75/17.5', '235/75/17.5'),
        ('275/80/22.5', '275/80/22.5'),
        ('295/80/22.5', '295/80/22.5'),
    ]
    
    POSICOES_CHOICES = [
        ('dianteiro_esquerdo', 'Dianteiro Esquerdo'),
        ('dianteiro_direito', 'Dianteiro Direito'),
        ('traseiro_esquerdo_1', 'Traseiro Esquerdo 1'),
        ('traseiro_direito_1', 'Traseiro Direito 1'),
        ('traseiro_esquerdo_2', 'Traseiro Esquerdo 2'),
        ('traseiro_direito_2', 'Traseiro Direito 2'),
        ('estepe', 'Estepe'),
    ]
    
    veiculo = models.ForeignKey(Veiculo, on_delete=models.CASCADE, related_name='pneus')
    posicao = models.CharField(max_length=30, choices=POSICOES_CHOICES, verbose_name='Posição no Veículo')
    marca = models.CharField(max_length=50, verbose_name='Marca')
    modelo = models.CharField(max_length=100, verbose_name='Modelo')
    medida = models.CharField(max_length=20, choices=MEDIDAS_CHOICES, verbose_name='Medida do Pneu')
    pressao = models.DecimalField(max_digits=5, decimal_places=1, verbose_name='Pressão (PSI)')
    profundidade_sulco = models.DecimalField(max_digits=4, decimal_places=1, verbose_name='Profundidade do Sulco (mm)')
    custo = models.DecimalField(max_digits=10, decimal_places=2, verbose_name='Custo')
    data_instalacao = models.DateField(verbose_name='Data de Instalação')
    km_instalacao = models.IntegerField(verbose_name='KM na Instalação')
    fornecedor = models.CharField(max_length=100, verbose_name='Fornecedor')
    lote_fabricacao = models.CharField(max_length=50, verbose_name='Lote de Fabricação')
    numero_serie = models.CharField(max_length=50, verbose_name='Número de Série')
    marca_fogo = models.CharField(max_length=50, verbose_name='Marca Fogo')
    observacoes = models.TextField(blank=True, verbose_name='Observações Técnicas')
    data_cadastro = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name = 'Pneu'
        verbose_name_plural = 'Pneus'
        ordering = ['-data_cadastro']
        unique_together = ['veiculo', 'posicao']
    
    def __str__(self):
        return f"{self.veiculo.placa} - {self.get_posicao_display()} - {self.marca} {self.modelo}"
"""

# ----- xbpneus/apps/frota/models_estoque.py (NOVO SISTEMA) -----
"""
from django.db import models
from django.contrib.auth.models import User
from .models import Veiculo

class PneuEstoque(models.Model):
    STATUS_CHOICES = [
        ('disponivel', 'Disponível'),
        ('em_uso', 'Em uso'),
        ('reformado', 'Reformado'),
        ('descartado', 'Descartado'),
    ]
    
    TIPO_CHOICES = [
        ('novo', 'Novo'),
        ('usado', 'Usado'),
        ('reformado', 'Reformado'),
    ]
    
    MEDIDAS_CHOICES = [
        ('225/75/16', '225/75/16'),
        ('215/75/17.5', '215/75/17.5'),
        ('235/75/17.5', '235/75/17.5'),
        ('275/80/22.5', '275/80/22.5'),
        ('295/80/22.5', '295/80/22.5'),
        ('315/80/22.5', '315/80/22.5'),
    ]
    
    # Informações da Nota Fiscal
    usuario = models.ForeignKey(User, on_delete=models.CASCADE, related_name='pneus_estoque')
    numero_nf = models.CharField(max_length=50, verbose_name='Número da NF')
    fornecedor = models.CharField(max_length=100, verbose_name='Fornecedor')
    data_entrada = models.DateField(verbose_name='Data de Entrada')
    
    # Informações do Pneu
    marca = models.CharField(max_length=50, verbose_name='Marca')
    modelo = models.CharField(max_length=100, verbose_name='Modelo')
    medida = models.CharField(max_length=20, choices=MEDIDAS_CHOICES, verbose_name='Medida')
    tipo = models.CharField(max_length=20, choices=TIPO_CHOICES, verbose_name='Tipo')
    
    # Controle
    numero_serie = models.CharField(max_length=50, unique=True, verbose_name='Número de Série')
    dot = models.CharField(max_length=10, verbose_name='DOT (Data Fabricação)')
    valor_unitario = models.DecimalField(max_digits=10, decimal_places=2, verbose_name='Valor Unitário')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='disponivel', verbose_name='Status')
    
    # Observações
    observacoes = models.TextField(blank=True, verbose_name='Observações')
    data_cadastro = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name = 'Pneu em Estoque'
        verbose_name_plural = 'Pneus em Estoque'
        ordering = ['-data_cadastro']
    
    def __str__(self):
        return f"{self.marca} {self.modelo} - {self.medida} - {self.numero_serie}"

class VinculacaoPneu(models.Model):
    POSICOES_CHOICES = [
        ('dianteiro_esquerdo', 'Dianteiro Esquerdo'),
        ('dianteiro_direito', 'Dianteiro Direito'),
        ('intermediario_esquerdo_1', 'Intermediário Esquerdo 1'),
        ('intermediario_esquerdo_2', 'Intermediário Esquerdo 2'),
        ('intermediario_direito_1', 'Intermediário Direito 1'),
        ('intermediario_direito_2', 'Intermediário Direito 2'),
        ('traseiro_esquerdo_1', 'Traseiro Esquerdo 1'),
        ('traseiro_esquerdo_2', 'Traseiro Esquerdo 2'),
        ('traseiro_direito_1', 'Traseiro Direito 1'),
        ('traseiro_direito_2', 'Traseiro Direito 2'),
        ('estepe', 'Estepe'),
    ]
    
    # Relacionamentos
    pneu_estoque = models.ForeignKey(PneuEstoque, on_delete=models.CASCADE, related_name='vinculacoes')
    veiculo = models.ForeignKey(Veiculo, on_delete=models.CASCADE, related_name='pneus_vinculados')
    
    # Dados da montagem
    posicao = models.CharField(max_length=30, choices=POSICOES_CHOICES, verbose_name='Posição no Veículo')
    data_montagem = models.DateField(verbose_name='Data de Montagem')
    km_montagem = models.IntegerField(verbose_name='KM na Montagem')
    
    # Dados atuais
    pressao_atual = models.DecimalField(max_digits=5, decimal_places=1, null=True, blank=True, verbose_name='Pressão Atual (PSI)')
    sulco_externo = models.DecimalField(max_digits=4, decimal_places=1, null=True, blank=True, verbose_name='Sulco Externo (mm)')
    sulco_central = models.DecimalField(max_digits=4, decimal_places=1, null=True, blank=True, verbose_name='Sulco Central (mm)')
    sulco_interno = models.DecimalField(max_digits=4, decimal_places=1, null=True, blank=True, verbose_name='Sulco Interno (mm)')
    
    # Controle
    ativo = models.BooleanField(default=True, verbose_name='Ativo')
    data_remocao = models.DateField(null=True, blank=True, verbose_name='Data de Remoção')
    km_remocao = models.IntegerField(null=True, blank=True, verbose_name='KM na Remoção')
    motivo_remocao = models.TextField(blank=True, verbose_name='Motivo da Remoção')
    
    observacoes = models.TextField(blank=True, verbose_name='Observações')
    data_cadastro = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name = 'Vinculação de Pneu'
        verbose_name_plural = 'Vinculações de Pneus'
        ordering = ['-data_cadastro']
        unique_together = ['veiculo', 'posicao', 'ativo']
    
    def __str__(self):
        return f"{self.veiculo.placa} - {self.get_posicao_display()} - {self.pneu_estoque.marca}"
    
    def save(self, *args, **kwargs):
        # Atualizar status do pneu no estoque
        if self.ativo:
            self.pneu_estoque.status = 'em_uso'
        else:
            self.pneu_estoque.status = 'disponivel'
        self.pneu_estoque.save()
        super().save(*args, **kwargs)

class HistoricoMovimentacao(models.Model):
    TIPOS_MOVIMENTO = [
        ('entrada', 'Entrada no Estoque'),
        ('montagem', 'Montagem no Veículo'),
        ('remocao', 'Remoção do Veículo'),
        ('manutencao', 'Manutenção'),
        ('reforma', 'Reforma'),
        ('descarte', 'Descarte'),
    ]
    
    pneu_estoque = models.ForeignKey(PneuEstoque, on_delete=models.CASCADE, related_name='historico')
    tipo_movimento = models.CharField(max_length=20, choices=TIPOS_MOVIMENTO, verbose_name='Tipo de Movimento')
    data_movimento = models.DateTimeField(auto_now_add=True, verbose_name='Data do Movimento')
    
    # Dados opcionais dependendo do tipo de movimento
    veiculo = models.ForeignKey(Veiculo, on_delete=models.SET_NULL, null=True, blank=True, verbose_name='Veículo')
    km_veiculo = models.IntegerField(null=True, blank=True, verbose_name='KM do Veículo')
    custo = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True, verbose_name='Custo')
    
    descricao = models.TextField(verbose_name='Descrição')
    usuario = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name='Usuário')
    
    class Meta:
        verbose_name = 'Histórico de Movimentação'
        verbose_name_plural = 'Históricos de Movimentação'
        ordering = ['-data_movimento']
    
    def __str__(self):
        return f"{self.pneu_estoque} - {self.get_tipo_movimento_display()} - {self.data_movimento.strftime('%d/%m/%Y')}"
"""

# ===== 2. VIEWS PRINCIPAIS =====

# ----- xbpneus/apps/frota/views_estoque.py (NOVO SISTEMA) -----
"""
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Count, Sum, Q
from django.http import JsonResponse
from .models_estoque import PneuEstoque, VinculacaoPneu, HistoricoMovimentacao
from .forms_estoque import (
    PneuEstoqueForm, VinculacaoPneuForm, RemocaoPneuForm,
    AtualizacaoSulcoForm, HistoricoMovimentacaoForm, FiltroEstoqueForm
)
from .models import Veiculo

@login_required
def dashboard_estoque(request):
    pneus_estoque = PneuEstoque.objects.filter(usuario=request.user)
    
    # Estatísticas
    total_pneus = pneus_estoque.count()
    pneus_disponiveis = pneus_estoque.filter(status='disponivel').count()
    pneus_em_uso = pneus_estoque.filter(status='em_uso').count()
    pneus_reformados = pneus_estoque.filter(status='reformado').count()
    pneus_descartados = pneus_estoque.filter(status='descartado').count()
    
    # Valor total do estoque
    valor_total = pneus_estoque.aggregate(total=Sum('valor_unitario'))['total'] or 0
    valor_disponivel = pneus_estoque.filter(status='disponivel').aggregate(
        total=Sum('valor_unitario')
    )['total'] or 0
    
    # Pneus por marca
    pneus_por_marca = pneus_estoque.values('marca').annotate(
        total=Count('id')
    ).order_by('-total')[:5]
    
    # Últimas movimentações
    ultimas_movimentacoes = HistoricoMovimentacao.objects.filter(
        pneu_estoque__usuario=request.user
    )[:10]
    
    context = {
        'total_pneus': total_pneus,
        'pneus_disponiveis': pneus_disponiveis,
        'pneus_em_uso': pneus_em_uso,
        'pneus_reformados': pneus_reformados,
        'pneus_descartados': pneus_descartados,
        'valor_total': valor_total,
        'valor_disponivel': valor_disponivel,
        'pneus_por_marca': pneus_por_marca,
        'ultimas_movimentacoes': ultimas_movimentacoes,
    }
    return render(request, 'frota/estoque/dashboard.html', context)
"""

# ===== 3. CONFIGURAÇÕES =====

# ----- xbpneus/config/settings.py -----
"""
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'xbpneus.apps.home',
    'xbpneus.apps.produtos',
    'xbpneus.apps.servicos',
    'xbpneus.apps.contato',
    'xbpneus.apps.frota',
    'xbpneus.apps.subusuarios',
    'xbpneus.apps.transportadores',
    'xbpneus.core',
]

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': os.environ.get('PGDATABASE'),
        'USER': os.environ.get('PGUSER'),
        'PASSWORD': os.environ.get('PGPASSWORD'),
        'HOST': os.environ.get('PGHOST'),
        'PORT': os.environ.get('PGPORT', 5432),
    }
}
"""

# ===== 4. URLS =====

# ----- xbpneus/apps/frota/urls.py -----
"""
from django.urls import path, include
from . import views

app_name = 'frota'

urlpatterns = [
    # Dashboard
    path('', views.dashboard_frota, name='dashboard'),
    
    # Veículos
    path('veiculos/', views.listar_veiculos, name='listar_veiculos'),
    path('veiculos/cadastrar/', views.cadastrar_veiculo, name='cadastrar_veiculo'),
    path('veiculos/<int:veiculo_id>/', views.detalhes_veiculo, name='detalhes_veiculo'),
    path('veiculos/<int:veiculo_id>/editar/', views.editar_veiculo, name='editar_veiculo'),
    
    # Pneus (sistema antigo - manter para compatibilidade)
    path('pneus/', views.listar_pneus, name='listar_pneus'),
    path('pneus/cadastrar/', views.cadastrar_pneu, name='cadastrar_pneu'),
    path('pneus/cadastrar/<int:veiculo_id>/', views.cadastrar_pneu, name='cadastrar_pneu_veiculo'),
    path('pneus/<int:pneu_id>/editar/', views.editar_pneu, name='editar_pneu'),
    
    # Estoque de Pneus (novo sistema)
    path('estoque/', include('xbpneus.apps.frota.urls_estoque')),
    
    # Relatórios
    path('relatorios/', views.relatorios, name='relatorios'),
]
"""

# ===== 5. FORMULÁRIOS =====

# ----- xbpneus/apps/frota/forms_estoque.py -----
"""
from django import forms
from .models_estoque import PneuEstoque, VinculacaoPneu, HistoricoMovimentacao
from .models import Veiculo

class PneuEstoqueForm(forms.ModelForm):
    class Meta:
        model = PneuEstoque
        fields = [
            'numero_nf', 'fornecedor', 'data_entrada',
            'marca', 'modelo', 'medida', 'tipo',
            'numero_serie', 'dot', 'valor_unitario',
            'observacoes'
        ]

class VinculacaoPneuForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        self.usuario = kwargs.pop('usuario', None)
        super().__init__(*args, **kwargs)
        
        if self.usuario:
            # Filtrar apenas veículos do usuário
            self.fields['veiculo'].queryset = Veiculo.objects.filter(usuario=self.usuario)
            
            # Filtrar apenas pneus disponíveis do usuário
            self.fields['pneu_estoque'].queryset = PneuEstoque.objects.filter(
                usuario=self.usuario,
                status='disponivel'
            )
    
    class Meta:
        model = VinculacaoPneu
        fields = [
            'pneu_estoque', 'veiculo', 'posicao',
            'data_montagem', 'km_montagem',
            'pressao_atual', 'observacoes'
        ]
"""

# ===== INSTRUÇÕES PARA IMPLEMENTAÇÃO DE MÉTRICAS AVANÇADAS =====

"""
CHATGPT - IMPLEMENTE AS SEGUINTES MÉTRICAS E FUNCIONALIDADES:

1. ANÁLISE DE DESEMPENHO:
   - Calcular KM médio por pneu (km_remocao - km_montagem)
   - Custo por KM rodado (valor_unitario / km_rodados)
   - Vida útil média por marca/modelo
   - ROI de pneus reformados vs novos
   - Ranking de marcas por durabilidade

2. PREDIÇÕES E ALERTAS:
   - Algoritmo de previsão de troca baseado em padrões de desgaste
   - Alertas de estoque mínimo por medida
   - Sugestões de compra otimizada
   - Identificação de padrões anômalos de desgaste
   - Alertas de manutenção preventiva

3. ANÁLISE FINANCEIRA:
   - TCO (Total Cost of Ownership) por veículo
   - Análise de performance de fornecedores
   - Sazonalidade de preços e sugestões de compra
   - Budget vs realizado
   - Projeções de gastos futuros

4. EFICIÊNCIA OPERACIONAL:
   - Tempo médio entre montagem e desmontagem
   - Produtividade da frota (KM/mês por veículo)
   - Indicadores de manutenção preventiva
   - Benchmarking entre veículos similares
   - Otimização de rotas baseada em desgaste

5. DASHBOARDS EXECUTIVOS:
   - KPIs consolidados em tempo real
   - Gráficos de tendência (Chart.js ou similar)
   - Comparativos mensais/anuais
   - Alertas críticos no dashboard
   - Relatórios executivos em PDF

6. FUNCIONALIDADES ADICIONAIS:
   - Sistema de notificações por email/SMS
   - API REST para integração com outros sistemas
   - Exportação de dados para Excel/CSV
   - Backup automático de dados críticos
   - Auditoria de alterações

TECNOLOGIAS SUGERIDAS:
- Chart.js para gráficos
- Django REST Framework para APIs
- Celery para tarefas assíncronas
- Redis para cache
- Pandas para análise de dados
- Scikit-learn para machine learning

ESTRUTURA DE ARQUIVOS SUGERIDA:
- analytics/ (novo app para métricas)
- notifications/ (sistema de alertas)
- reports/ (relatórios avançados)
- api/ (endpoints REST)
"""

print("=== BACKUP COMPLETO GERADO ===")
print("Arquivo: backup_xbpneus_completo.md")
print("Código: codigo_fonte_completo.py")
print("Status: Pronto para análise do ChatGPT")

