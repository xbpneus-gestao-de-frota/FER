# Core app - Funcionalidades centrais do XBPNEUS

