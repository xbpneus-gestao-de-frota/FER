from django.apps import AppConfig


class ContatoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'xbpneus.apps.contato'
    verbose_name = 'Contato'

