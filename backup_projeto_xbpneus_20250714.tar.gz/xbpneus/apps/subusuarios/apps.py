from django.apps import AppConfig

class SubusuariosConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'xbpneus.apps.subusuarios'
    verbose_name = 'Subusuários'

