default_app_config = 'xbpneus.apps.subusuarios.apps.SubusuariosConfig'

