from django.apps import AppConfig


class ServicosConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'xbpneus.apps.servicos'
    verbose_name = 'Serviços'

