from django.contrib import admin

# Home app admin - pode ser usado para banners, depoimentos, etc. no futuro

