from django.db import models

# Home app não precisa de models específicos por enquanto
# Pode ser usado para banners, depoimentos, etc. no futuro

